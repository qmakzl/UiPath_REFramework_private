import os 
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split
from joblib import load
import pandas as pd 
import joblib
class Main:
    def __init__(self):
        self.curr_dir = os.path.dirname(os.path.abspath("__file__"))
        self.target_column = 'Churn'
        self.preprocess = load('model/preprocess.joblib')
        self.model = load('model/model.joblib')
    
    def train(self, training_directory):
        (X_train, y_train) = self.load_data(training_directory)
        X_train = self.preprocess.transform(X_train)
        y_train = y_train.map({'Yes': 1, 'No': 0})

        self.model = LogisticRegression(solver = "newton-cg")
        self.model.fit(X_train, y_train)
        return self.model
    
    def evaluate(self, evaluation_directory):        
        (X_test, y_test) = self.load_data(evaluation_directory)
        X_test = self.preprocess.transform(X_test)
        y_test = y_test.map({'Yes': 1, 'No': 0})
        
        y_pred = self.model.predict(X_test)
        return f1_score(y_test, y_pred)
    
    def save(self):
        #save trained model
        joblib.dump(self.model, 'model/model.joblib')      
    
    def process_data(self, data_directory):
        X, y = self.load_data(data_directory)
        
        # Split into train and evaluation set and save to csv
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=10, stratify=y)        
        train_df = pd.DataFrame(X_train, columns=self.feature_columns)
        train_df[self.target_column] = y_train
        train_df.to_csv('test1.csv')
        train_df.to_csv(os.path.join(self.curr_dir, data_directory, 'training', 'train.csv'), index=False)

        test_df = pd.DataFrame(X_test, columns = self.feature_columns)
        test_df[self.target_column] = y_test
        test_df.to_csv(os.path.join(self.curr_dir, data_directory, 'test', 'evaluate.csv'), index=False)
        
    def load_data(self, data_directory):
        df_list = []
        for filename in os.listdir(os.path.join(self.curr_dir, data_directory)):
            if not os.path.isfile(os.path.join(self.curr_dir, data_directory, filename)):
                continue
            if filename[-4:] == '.csv':
                df_list.append(pd.read_csv(os.path.join(self.curr_dir, data_directory, filename), header=0, encoding="utf-8"))    

        data = pd.concat(df_list, axis=0)        
        self.feature_columns = data.drop(self.target_column, axis=1).columns
        
        X = data[self.feature_columns]        
        y = data[self.target_column]
        
        return X, y